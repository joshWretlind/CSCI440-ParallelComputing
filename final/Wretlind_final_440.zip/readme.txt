To make the program, just type make

I included a run script(called using ./run). What this script does is it both does SHA3-256 and SHA3-512 for .5 MB, 1 MB, and 1.5 MB file sizes, and perfoms it for processor counts of 1 to 80. Then, it does the same thing, but adding processors from alamode and going from 1 to 160. 

